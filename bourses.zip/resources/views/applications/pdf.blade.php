<html>

<head>
    <title></title>
    <style type="text/css">
        body {
            font-family: Arial;
            font-size: 17.1px
        }

        .pos {
            position: absolute;
            z-index: 0;
            left: 0px;
            top: 0px
        }
    </style>
</head>

<body>
    <nobr>
        <nowrap>
            <div class="pos" id="_0:0" style="top:0">
                {{-- <img name="_1170:828" src="page_001.jpg" height="1170" width="828" border="0" usemap="#Map"> --}}
            </div>
            <div class="pos" id="_66:77" style="top:77;left:66">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    REPUBLIQUE DU CAMEROUN</span>
            </div>
            <div class="pos" id="_527:77" style="top:77;left:427">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    REPUBLIC OF CAMEROON Peace-Work-</span>
            </div>
            <div class="pos" id="_104:92" style="top:92;left:104">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    Palx-Travail-Patrie</span>
            </div>
            <div class="pos" id="_616:92" style="top:92;left:516">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    Fatherland</span>
            </div>
            <div class="pos" id="_124:106" style="top:106;left:124">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    *************</span>
            </div>
            <div class="pos" id="_622:106" style="top:106;left:622">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    **********</span>
            </div>
            <div class="pos" id="_51:120" style="top:120;left:51">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    MINISTERE DE L'EMPLOI ET DE LA </span>
            </div>
            <div class="pos" id="_545:120" style="top:120;left:545">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    MINISTRY OF EMPLOYMENT AND </span>
            </div>
            <div class="pos" id="_129:135" style="top:135;left:129">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    ***********</span>
            </div>
            <div class="pos" id="_574:135" style="top:135;left:574">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    VOCATIONAL TRAINING</span>
            </div>
            <div class="pos" id="_55:149" style="top:149;left:55">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    FORMATION PROFESSIONNELLE</span>
            </div>
            <div class="pos" id="_622:149" style="top:149;left:622">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    **********</span>
            </div>
            <div class="pos" id="_129:164" style="top:164;left:129">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    ***********</span>
            </div>
            <div class="pos" id="_570:164" style="top:164;left:570">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    SECRETARIAT GENERAL</span>
            </div>
            <div class="pos" id="_80:178" style="top:178;left:80">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    SECRETARIAT GENERAL</span>
            </div>
            <div class="pos" id="_622:178" style="top:178;left:622">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    **********</span>
            </div>
            <div class="pos" id="_134:192" style="top:192;left:134">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    *********</span>
            </div>
            <div class="pos" id="_550:192" style="top:192;left:550">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    DEPARTMENT OF VOCATIONAL </span>
            </div>
            <div class="pos" id="_42:207" style="top:207;left:42">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    DIRECTION DE LA FORMATION ET DE </span>
            </div>
            <div class="pos" id="_566:207" style="top:207;left:566">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    TRAINING AND GUIDANCE</span>
            </div>
            <div class="pos" id="_41:221" style="top:221;left:41">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    L'ORIENTATION PROFESSIONNELLES</span>
            </div>
            <div class="pos" id="_129:235" style="top:235;left:129">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    ***********</span>
            </div>
            <div class="pos" id="_50:338" style="top:338;left:50">
                <span id="_14.8" style="font-weight:bold; font-family:Arial; font-size:14.8px; color:#000000">
                    FICHE DE CANDIDATURE A LA BOURSE DE FORMATION PROFESSIONNELLE</span>
            </div>
            <div class="pos" id="_50:358" style="top:358;left:50">
                <span id="_12.1" style=" font-family:Arial; font-size:12.1px; color:#000000">
                    (A produire en deux (2) exemplaires apr&#232;s l'entretien avec le Conseiller d'Orientation
                    Professionnelle)</span>
            </div>
            <div class="pos" id="_50:415" style="top:415;left:50">
                <span id="_14.8" style="font-weight:bold; font-family:Arial; font-size:14.8px; color:#000000">
                    IDENTITE DU CANDIDAT</span>
            </div>
            <div class="pos" id="_50:455" style="top:455;left:50">
                <span id="_13.5" style=" font-family:Arial; font-size:13.5px; color:#000000">
                    Nom:<u>{{ $application->first_name }}</u> Date de naissance: <u>{{ $application->dob }}</u></span>
            </div>
            <div class="pos" id="_50:492" style="top:492;left:50">
                <span id="_13.5" style=" font-family:Arial; font-size:13.5px; color:#000000">
                    Pr&#233;noms:<u>{{ $application->last_name }}</u> Lieu de naissance: <u>{{ $application->pob }}</u> </span>
            </div>
            <div class="pos" id="_50:529" style="top:529;left:50">
                <span id="_13.5" style=" font-family:Arial; font-size:13.5px; color:#000000">
                    Ville de naissance<u>{{ $application->city }}</u> Quartier <u>{{ $application->address }}</u></span>
            </div>
            <div class="pos" id="_50:566" style="top:566;left:50">
                <span id="_13.5" style=" font-family:Arial; font-size:13.5px; color:#000000">
                    Region d'origine:<u>{{ $application->region }}</u></span>
            </div>
            <div class="pos" id="_50:602" style="top:602;left:50">
                <span id="_13.5" style=" font-family:Arial; font-size:13.5px; color:#000000">
                    Telephone:<u>{{ $application->phone }}</u></span>
            </div>
            <div class="pos" id="_50:639" style="top:639;left:50">
                <span id="_13.5" style=" font-family:Arial; font-size:13.5px; color:#000000">
                    Email:<u>{{ $application->email }}</u></span>
            </div>
            <div class="pos" id="_50:740" style="top:740;left:50">
                <span id="_12.1" style="font-weight:bold; font-family:Arial; font-size:12.1px; color:#000000">
                    CHOIX DU CANDIDAT</span>
            </div>
            <div class="pos" id="_50:773" style="top:773;left:50">
                <span id="_12.1" style="font-weight:bold; font-family:Arial; font-size:12.1px; color:#000000">premier choix</span>:
                {{ $application->choice_1->name }}
            </div>
            <div class="pos" id="_107:790" style="top:790;left:107">
                <span id="_12.1" style="font-weight:bold; font-family:Arial; font-size:12.1px; color:#000000">Sp&#233;cialit&#233; choisis</span>:
                {{ $application->choice_1->specialty }}
            </div>
            <div class="pos" id="_107:807" style="top:807;left:107">
                <span id="_12.1" style="font-weight:bold; font-family:Arial; font-size:12.1px; color:#000000">
                    Localit&#233; choisie</span>
                    <span>
                        {{ $application->first_choice_location }}
                    </span>
            </div>
            <div class="pos" id="_50:858" style="top:858;left:50">
                <span id="_11.8" style="font-weight:bold; font-family:Arial; font-size:11.8px; color:#000000">
                    deuxi&#232;me choix</span><span>
                        {{ $application->choice_2->name }}
                    </span>
            </div>
            <div class="pos" id="_107:875" style="top:875;left:107">
                <span id="_11.8" style="font-weight:bold; font-family:Arial; font-size:11.8px; color:#000000">
                    Sp&#233;cialit&#233; choisis</span><span>
                        : {{ $application->choice_2->specialty }}
                    </span>
            </div>
            <div class="pos" id="_107:892" style="top:892;left:107">
                <span id="_11.8" style="font-weight:bold; font-family:Arial; font-size:11.8px; color:#000000">
                    Localit&#233; choisie</span><span>
                        : {{ $application->second_choice_location }}
                    </span>
            </div>
            <div class="pos" id="_50:942" style="top:942;left:50">
                <span id="_11.8" style="font-weight:bold; font-family:Arial; font-size:11.8px; color:#000000">
                    troisi&#232;me choix</span>
                    <span>
                        : {{ $application->choice_3->name }}
                    </span>
            </div>
            <div class="pos" id="_107:959" style="top:959;left:107">
                <span id="_11.8" style="font-weight:bold; font-family:Arial; font-size:11.8px; color:#000000">
                    Sp&#233;cialit&#233; choisis</span>
                    <span>
                        : {{ $application->choice_3->specialty }}
                    </span>
            </div>
            <div class="pos" id="_107:977" style="top:977;left:107">
                <span id="_11.8" style="font-weight:bold; font-family:Arial; font-size:11.8px; color:#000000">
                    Localit&#233; choisle</span>
                    <span>
                        : {{ $application->third_choice_location }}
                    </span>
            </div>

        </nowrap>
    </nobr>
</body>

</html>
